g++ -w -o criptografia main.cpp -g -W -Wall -pedantic -ansi
